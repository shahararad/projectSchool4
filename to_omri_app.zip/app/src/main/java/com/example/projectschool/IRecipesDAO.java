package com.example.projectschool;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Update;

@Dao
public interface IRecipesDAO {
    @Insert
    long insertRecipe(Recipes Recipe);

    @Delete
    int deleteRecipe(Recipes Recipe);

    @Update
    int updateRecipe( Recipes Recipe);

}
