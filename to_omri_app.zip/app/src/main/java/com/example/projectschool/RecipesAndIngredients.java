package com.example.projectschool;

import androidx.room.Entity;
import androidx.room.ForeignKey;

@Entity(primaryKeys = {"ingredName", "recipeName"} ,foreignKeys = {
        @ForeignKey(entity = Ingredients.class,
            parentColumns = "ingredName",
            childColumns = "ingredName",
            onDelete = ForeignKey.NO_ACTION),
        @ForeignKey(entity = Recipes.class,
                parentColumns = "recipeName",
                childColumns = "recipeName",
                onDelete =ForeignKey.CASCADE)

})

public class RecipesAndIngredients {

    public int ingredName;
    public int recipeName;


}
