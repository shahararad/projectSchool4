package com.example.projectschool;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity

public class User {

    @PrimaryKey(autoGenerate = true)
    public String UserName;

    public String Password;

    public User(String UserName, String Password){
        this.Password= Password;
        this.UserName= UserName;
    }



}
