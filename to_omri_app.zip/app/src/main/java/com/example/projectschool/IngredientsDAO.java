package com.example.projectschool;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Update;

@Dao
public interface IngredientsDAO {
    @Insert()
    long insertIngredient(Ingredients ingredient);

    @Delete
    int deleteIngredient(Ingredients ingredient);

    @Update
    int updateIngredient( Ingredients ingredient);




}
