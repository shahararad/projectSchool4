package com.example.projectschool;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Recipes {

   // public int recipeId;// the recipe Id
    @NonNull
   @PrimaryKey(autoGenerate = false)
    public String recipeName;// the recipe name

    public String recipeInstructions;// the recipe

    public Recipes(String recipeName,String recipeInstructions){//constructor
        this.recipeName= recipeName;
        this.recipeInstructions= recipeInstructions;
    }
    public Recipes(){

    }







}
