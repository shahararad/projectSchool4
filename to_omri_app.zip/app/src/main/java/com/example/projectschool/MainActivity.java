package com.example.projectschool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Database;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public EditText enteringredent;
    public TextView text;
    public Button button;

    AppDatabase database;
    IngredientsDAO ingredientsDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        enteringredent= findViewById(R.id.enteringredent);
        text= findViewById(R.id.text1);
        button= findViewById(R.id.button);
         database = AppDatabase.getDataBase(MainActivity.this);
         ingredientsDAO = database.ingredientsDAO();



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppDatabase.databaseWriteExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Ingredients ingredients = new Ingredients(enteringredent.getText().toString());
                        ingredientsDAO.insertIngredient(ingredients);
                    }
                });
            }
        });
    }

}