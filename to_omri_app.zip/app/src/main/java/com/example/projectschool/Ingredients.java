package com.example.projectschool;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity

public class Ingredients {
    @NonNull
    @PrimaryKey(autoGenerate = false)
    public String ingredName;// the name of the Item

    //public int ingredId;// Id of the Item

    public Ingredients(String ingredName){
        this.ingredName= ingredName;
    }
    public Ingredients(){

    }










}
