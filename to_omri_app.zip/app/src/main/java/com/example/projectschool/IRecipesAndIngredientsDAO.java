package com.example.projectschool;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Update;
@Dao
public interface IRecipesAndIngredientsDAO {

    @Insert
    long insertIngredient(RecipesAndIngredients recipesAndIngredients);

    @Delete
    int deleteIngredient(RecipesAndIngredients recipesAndIngredients);

    @Update
    int updateIngredient( RecipesAndIngredients recipesAndIngredients);


}
