package com.example.projectschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomePageActivity extends AppCompatActivity {
    public Button shoopingButton;
    public Button cookButton;
    public Button haveButton;
    public TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        shoopingButton= findViewById(R.id.shopList);
        cookButton=findViewById(R.id.cook);
        haveButton= findViewById(R.id.alreadyHave);
        welcomeText= findViewById(R.id.welcomText);

        shoopingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                            synchronized (this) {
                                Intent intent = new Intent
                                        (HomePageActivity.this,ShoppingListPage.class);
                                startActivity(intent);
                                finish();}


                    }
                }).start();

            }
        });
        cookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        synchronized (this) {
                            Intent intent = new Intent
                                    (HomePageActivity.this,cookPage.class);
                            startActivity(intent);
                            finish();}


                    }
                }).start();
            }
        });
        haveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        synchronized (this) {
                            Intent intent = new Intent
                                    (HomePageActivity.this,IHaveItPage.class);
                            startActivity(intent);
                            finish();}


                    }
                }).start();
            }
        });






    }
}