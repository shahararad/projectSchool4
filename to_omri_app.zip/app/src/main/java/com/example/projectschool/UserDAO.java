package com.example.projectschool;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao

public interface UserDAO {

    @Insert()
    long insertIngredient(Ingredients ingredient);

    @Delete
    int deleteIngredient(Ingredients ingredient);

    @Update
    int updateIngredient( Ingredients ingredient);

    @Query("Select * From User")
    LiveData< List<User>> getallUsers();

    @Query("Select * From User Where UserName= :userName  ")
    LiveData< List<User>> getUserById(String userName);

}
